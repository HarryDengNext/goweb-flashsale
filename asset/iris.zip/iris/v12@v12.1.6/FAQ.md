# FAQ

## [![iris](https://img.shields.io/badge/iris-powered-2196f3.svg?style=for-the-badge)](https://github.com/kataras/iris)

Add a `badge` to your open-source projects powered by [Iris](https://iris-go.com) by pasting the below code snippet to the project repo's README.md:

```md
[![iris](https://img.shields.io/badge/iris-powered-2196f3.svg?style=for-the-badge)](https://github.com/kataras/iris)
```

> The badge is optionally, of course, it is just a simple and fast way to support Iris. The badge is work of a third-party, taken from https://github.com/blob-go/blob-go which was published by our friend @clover113 and we loved it<3

## Editors & IDEs Extensions

### Visual Studio Code <a href="https://marketplace.visualstudio.com/items?itemName=kataras2006.iris"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2d/Visual_Studio_Code_1.18_icon.svg/2000px-Visual_Studio_Code_1.18_icon.svg.png" height="20px" width="20px" /></a>

<https://marketplace.visualstudio.com/items?itemName=kataras2006.iris>

> Please feel free to list your own Iris extension(s) here by [PR](https://github.com/kataras/iris/pulls)

## How to upgrade

```sh
go get -u github.com/kataras/iris/v12@latest
```

Go version 1.13 and above is required.

## Learning

More than 100 practical examples, tutorials and articles at:

- https://iris-go.com/start
- https://github.com/kataras/iris/wiki/Starter-kits
- https://github.com/iris-contrib/examples
- https://godoc.org/github.com/kataras/iris
- https://bit.ly/iris-req-book

## Active development mode

Iris may have reached version 12, but we're not stopping there. We have many feature ideas on our board that we're anxious to add and other innovative web development solutions that we're planning to build into Iris.

## Can I find a job if I learn how to use Iris?

Yes, not only because you will learn Golang in the same time, but there are some positions
open for Iris-specific developers the time we speak.

Go to our facebook page, like it and receive notifications about new job offers, we already have couple of them stay at the top of the page: https://www.facebook.com/iris.framework

## Do we have a community Chat?

Yes, https://chat.iris-go.com

## How is the development of Iris supported?

By normal people, like you, who help us by donating small or large amounts of money.

Help this project deliver awesome and unique features with the highest possible code quality by donating any amount via [PayPal](https://www.paypal.me/kataras). Your name will be published [here](https://iris-go.com) after your approval via e-mail.
